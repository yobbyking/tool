# 👑 MEGH MD v4.3 — Premium Multi-User WhatsApp Bot

> Multi-user WhatsApp bot built with the official Baileys library. **Anyone can pair + connect** — each user gets their own isolated bot instance. Pairing via code (no QR scanning), 50+ commands, anti-commands, JSON session DB, and a slick MEGH MD × YOBBY branded pairing site. **Built for everyone — every user who pairs owns their own bot. No session limit.**

![MEGH MD Banner](public/assets/menu-banner.png)

## ✨ What's new in v4.3

- 🐛 **CRITICAL FIX: Baileys browser descriptor corrected** — was using `['MEGH MD','Chrome','120.0.0']` which set "MEGH MD" as the OS, causing WhatsApp to silently reject device linking (code was generated but pairing failed). Now uses `Browsers.appropriate('MEGH MD')` which returns `['Ubuntu','MEGH MD','22.04.4']` — a proper OS fingerprint with the bot name as the browser. **This is almost certainly why pairing wasn't working.**
- ♾️ **No session limit** — Removed `MAX_SESSIONS` enforcement entirely. Bot is for everyone. (Each Baileys socket uses ~30-50MB RAM; scale your host accordingly.)
- 🧹 **Cleaned stale sessions.json** — All previously stuck "pairing" sessions cleared, so they won't block new pairings.
- 🚫 **Removed "Max" stat from UI** — Stats card now shows only "Active" and "Total Paired" (per user request).
- 🚫 **Removed max-sessions chip** from status ribbon.
- 🧠 **Smarter connection.close handling** — 401 during pairing no longer auto-reconnects (which was losing the pairing context); instead marks as disconnected so user can request a fresh code.
- 🔍 **Better logging** — connection.update now logs `receivedPendingNotifications` and the actual error message, not just the status code.
- ⚙️ **`markOnlineOnConnect: false`** — less suspicious to WhatsApp.
- ⚙️ **`linkPreview: false`** — disables link preview (cleaner message flow).

## ✨ What was new in v4.2

- 📞 **Pairing flow hardened** — Confirmed the bot DOES communicate with WhatsApp (the pairing code returned is a real code requested directly from WhatsApp's servers, not generated locally). Added detailed logging so you can verify each step in the server console.
- 🆔 **Pairing code now formatted with a dash** — `3YBE7G9J` → `3YBE-7G9J`. WhatsApp accepts both formats, but the dash makes the code easier to read and type.
- 📞 **Phone number normalization** — `0712345678` (local) and `+254712345678` (with plus) and `254712345678` (international) are now all accepted. The server strips `+`, spaces, and a leading `0` so Baileys always receives a clean international number.
- ⏱️ **TTL bumped to 90 seconds** — Was 60s. Gives users more time to open WhatsApp and enter the code.
- 🧪 **Added `wsReady` check** — After the QR event fires, we now also wait up to 5s for `sock.wsReady` to ensure the WebSocket is fully connected before requesting the pairing code.
- 👑 **Renamed MERG MD → MEGH MD** everywhere (bot name, browser identifier, banner text, package name, render service name, README, UI, asset filenames).

## ✨ What was new in v4.1

- 👑 **MEGH MD branding** — Bot rebranded from BOBOH MD to **MEGH MD** (Powered by YOBBY).
- 🖼️ **Image + caption menu** — `.menu` now ALWAYS sends the MEGH MD banner image with the full command list as caption. No more silent text-only fallback.
- 🐛 **Bug fixes**:
  - `.owner` no longer throws `ReferenceError: msg is not defined`
  - Removed dead `sharp` SVG→PNG conversion (which was failing silently)
  - BOT_NAME now consistent across `server.js`, `bot.js`, `sessionManager.js`
  - Welcome message also sends the MEGH MD banner image
- 🎨 **Redesigned pairing site** — Dark red/black premium theme with:
  - Hero banner showing the MEGH MD image
  - Live status chips (online/offline, active sessions, total paired)
  - Bebas Neue display font for the "MEGH MD" title
  - Animated glow orbs + noise + scanline overlay
  - Toast notifications, auto-formatting phone input, Enter-to-submit
  - Copy-to-clipboard with toast feedback
- 🛡️ **Same multi-user engine** — Each WhatsApp user gets their own isolated Baileys socket, auth folder, and DB record.
- 🆕 **`.whoami` command** — Every paired user can verify their own session info (number, mode, status, pairing date, command count).
- 📊 **Per-user stats now actually work** — `commandsExecuted` and `messagesReceived` counters are properly incremented per user. Previously a stale comment claimed JSON db couldn't do this.

## 🚀 Quick Start

### Local development

```bash
git clone https://github.com/xtechkin-svg/YOBBY-MD.git
cd YOBBY-MD
npm install
npm start            # No .env file needed — all defaults work
```

Open `http://localhost:3001` → enter your phone number → get pairing code.

> 💡 **No env vars needed!** All settings have sensible defaults. Each user owns their own bot instance.

### Deploy on Render (zero-config!) 🚀

1. Fork this repo on GitHub
2. Go to **[render.com](https://render.com)** → sign up with GitHub (free)
3. Click **"New +"** → **"Web Service"**
4. Select your forked `YOBBY-MD` repo
5. Render auto-detects `render.yaml` — pre-fills everything:
   - **Build:** `npm install`
   - **Start:** `node server.js`
   - **Plan:** Free (or Starter for always-on + persistent disk)
6. Click **"Create Web Service"** — that's it!
7. Wait ~2 minutes for the build
8. Visit your Render URL → pair your WhatsApp

> ⚠️ **Free tier sleep:** Render free tier sleeps after 15 min of no traffic. Use [UptimeRobot](https://uptimerobot.com) (free) to ping your Render URL every 5 min and keep it awake.

## 📋 Commands

Prefix: `.` (period) — each user can have their own prefix (stored in DB)

### Main
| Command | Description |
|---|---|
| `.menu` | Show all commands **with MEGH MD banner image** |
| `.ping` | Check bot latency |
| `.alive` | Show bot status |
| `.owner` | Show owner contact |
| `.whoami` | Show YOUR session info (per-user) |
| `.dp` | Set bot display picture (reply to image) |
| `.dp view` | View current DP |
| `.disconnect` | Disconnect this WhatsApp from the bot |

### Group Admin
| Command | Description |
|---|---|
| `.tagall <msg>` | Mention everyone |
| `.kick @user` | Remove a user |
| `.promote @user` | Make admin |
| `.demote @user` | Remove admin |
| `.mute` / `.unmute` | Group only-admins / open |
| `.link` | Get invite link |
| `.revoke` | Reset invite link |
| `.setname <name>` | Change group name |
| `.setdesc <desc>` | Change group description |
| `.delete` | Delete replied message |

### Media
| Command | Description |
|---|---|
| `.sticker <pack>` | Convert image to sticker |
| `.vv` | Unlock view-once media |
| `.tts <text>` | Text to speech |
| `.logo <text>` | Generate text logo |

### Tools
| Command | Description |
|---|---|
| `.url <long-url>` | Shorten URL |
| `.qr <text>` | Generate QR code |
| `.weather <city>` | Get weather |
| `.translate <lang> <text>` | Translate text |
| `.google <query>` | Search Google |
| `.wiki <query>` | Search Wikipedia |
| `.calculate <expr>` | Math calculator |

### Fun
| Command | Description |
|---|---|
| `.quote` `.joke` `.fact` | Random content |
| `.8ball <q>` `.coinflip` `.dice` | Games |
| `.truth` `.dare` | Truth or dare |

### Owner Only
| Command | Description |
|---|---|
| `.pp` | Set profile picture |
| `.block @user` `.unblock @user` | Block management |
| `.restart` `.shutdown` | Process control |

### Anti-Commands
| Command | Description |
|---|---|
| `.antilink on\|off\|kick` | Toggle anti-link per group |
| `.antibot on\|off` | Toggle anti-bot detection |
| Auto-anti-delete | Enabled by default (per-user setting) |
| Welcome/Goodbye | Auto on group join/leave |

## ⚙️ Configuration

Edit `.env` (all optional):

```env
PORT=3001
BOT_NAME=MEGH MD
PREFIX=.
IDLE_TIMEOUT_HOURS=6        # Auto-disconnect idle sessions (frees RAM)
PAIRING_CODE_TTL=90         # Pairing code expiry (seconds)
SITE_PASSWORD=              # Optional — require password to access pairing site
ANTI_DELETE=true
AUTO_READ_STATUS=true
SUPPORT_GROUP_INVITE=CEzNfBdOYHj6pWzWOrgISb   # Auto-join this group after pairing (set to 'disabled' to turn off)

# NOTE: This bot is multi-user — every user who pairs owns their own bot
# instance. There is NO global OWNER_NUMBER and NO max session limit.
# The welcome message is sent to each user who pairs, NOT to a global owner.
# Each Baileys socket uses ~30-50MB RAM. Scale your host based on expected
# concurrent users.
```

## 🛠️ Adding New Commands

Drop any `.js` file in `lib/commands/` with this format — auto-loaded on startup:

```js
module.exports = {
  name: 'mycommand',
  aliases: ['mc', 'mycmd'],
  desc: 'Does something cool',
  category: 'fun',
  async execute({ sock, msg, args, reply, from, isGroup, dbSession, prefix, botName, pushName }) {
    await reply('Hello from my custom command!');
  },
};
```

Use it with `.mycommand` or `.mc`.

## 📁 Project Structure

```
YOBBY-MD/
├── server.js              # Express pairing server + multi-user endpoints
├── package.json
├── render.yaml            # Render.com deployment
├── vercel.json            # Vercel config
├── lib/
│   ├── db.js              # JSON-file session store (no external DB needed)
│   ├── sessionManager.js  # Multi-user session manager (Baileys)
│   ├── handler.js         # Message router + command loader
│   ├── bot.js             # Legacy single-user Baileys connector (kept for reference)
│   ├── commands/          # 50+ command modules
│   └── anti/              # Anti-command modules
└── public/
    ├── index.html         # MEGH MD × YOBBY themed pairing site
    └── assets/
        ├── menu-banner.png  # ★ MEGH MD banner (used in .menu + welcome + site hero)
        ├── meghmd-logo.png  # MEGH MD logo
        ├── favicon.png      # Site favicon (same as banner)
        ├── gtav-logo.png    # (legacy) background logo
        ├── logo.svg         # (legacy) svg logo
        └── menu-banner.svg  # (legacy) svg banner
```

## ⚠️ Disclaimer

This bot is for educational purposes. Using automated bots on WhatsApp may violate their Terms of Service. Use at your own risk. The authors are not responsible for any account bans or legal issues.

## 📝 License

MIT — see [LICENSE](LICENSE).

## 👤 Author

**MEGH MD × YOBBY** — [GitHub](https://github.com/xtechkin-svg)

---

⭐ If you find this useful, star the repo!
